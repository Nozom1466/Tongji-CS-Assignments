#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <unordered_map>
#include <vector>

// ����ѧ�����ݽṹ
struct StudentInfo {
    std::string name;
    std::vector<int> grades;
};

int main() {
    std::string gradesFilename = "id-grades.txt";
    std::string namesFilename = "id-name.txt";
    std::string outputFilename = "name-grades.txt";

    // unordered_map ��Ӧ��ϵ 
    std::unordered_map<std::string, std::string> idToNameMap;

    std::ifstream namesFile(namesFilename);
    if (namesFile.is_open()) {
        std::string line;
        while (std::getline(namesFile, line)) {
            std::stringstream ss(line);
            std::string studentId, name;
            std::getline(ss, studentId, ',');
            std::getline(ss, name, ',');
            idToNameMap[studentId] = name;
        }
        namesFile.close();
    } else {
        std::cout << "FAIL-OPEN.\n";
        return 1;
    }
    std::ofstream outputFile(outputFilename);
    if (!outputFile.is_open()) {
        std::cout << "FAIL-OPEN.\n";
        return 1;
    }
    
    std::ifstream gradesFile(gradesFilename);
    if (gradesFile.is_open()) {
        std::string line;
        while (std::getline(gradesFile, line)) {
            std::stringstream ss(line);
            std::string studentId;
            std::getline(ss, studentId, ',');
            auto it = idToNameMap.find(studentId);
            if (it != idToNameMap.end()) {
                std::string name = it->second;
                outputFile << studentId << "  " << name << "  ";

                std::string grade;
                while (std::getline(ss, grade, ',')) {
                    outputFile << grade << "  ";
                }

                outputFile << "\n";
            }
        }
        gradesFile.close();
    } else {
        std::cout << "FAIL.\n";
        return 1;
    }

    outputFile.close();

    std::cout << "SUCCEEDED.\n";

    return 0;
}

