#include <iostream>
#include <math.h>
using namespace std;
#define PI 3.1415926

const int CANVAS_HEIGHT	= 720;
const int CANVAS_WIDTH	= 720;

const int INTERVALS_BT_RADIUS = 10;
const int RING_WIDTH = 64;
const int NORMAL_WIDTH = 10;
const int HOUR_RADIUS_MID = 256;
const int MINUTE_RADIUS_MID = HOUR_RADIUS_MID - INTERVALS_BT_RADIUS - RING_WIDTH;
const int SECOND_RADIUS_MID = MINUTE_RADIUS_MID - INTERVALS_BT_RADIUS - RING_WIDTH;



void init(int hour, int minute, int second) {
    //draw_donuts_bk();

    int radius;
    double radian;
    double temp_x, temp_y;
    if (hour > 12)
        hour -= 12;
    // fill in hour track
    for (int i = 0; i < hour % 12; i++) {
        radius = HOUR_RADIUS_MID;
        //setfillcolor(HOUR_COLOR);
        radian = 0;
        radius = HOUR_RADIUS_MID;
        temp_x = 0;
        temp_y = 0;
        for (int j = 0; j < 10; j++) {
            radian = j * PI / 60;
            temp_x = CANVAS_WIDTH / 2 + sin(i / 12 * 2 * PI + radian) * radius;
            temp_y = CANVAS_HEIGHT / 2 - cos(i / 12 * 2 * PI + radian) * radius;
            //cout << temp_x << " " << temp_y << endl;
            int increment;
            cout << static_cast<double>(minute) / 60 << endl;
            //cout << (increment = (static_cast<double>(minute) / 60) * PI / 6 + (static_cast<double>(second) / 3600) * PI / 6) << endl;
            //cout << hour % 12 / static_cast<double>(12) * 2 << endl;
            //solidcircle(floor(temp_x), floor(temp_y), RING_WIDTH / 2);
        }  
    }
}

int main() {
	init(7, 20, 50);
	return 0;
}
