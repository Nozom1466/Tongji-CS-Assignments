#include <iostream>
#include <fstream>
#include <random>

int main() {
    std::string filename = "id-grades.txt";
    std::ofstream file(filename);

    if (file.is_open()) {
        std::random_device rd;
        std::mt19937 gen(rd());
        std::uniform_int_distribution<int> gradeDist(60, 100);
        std::uniform_int_distribution<int> studentIdDist(2100000, 2199999);

        for (int i = 1; i <= 60; ++i) {
            int studentId = studentIdDist(gen);
            file << std::to_string(studentId) << ",";
            for (int j = 0; j < 4; ++j) {
                int grade = gradeDist(gen);
                file << std::to_string(grade) << ",";
            }
            file << gradeDist(gen) << "\n";
        }

        file.close();
        std::cout << "SUCC.\n";
    } else {
        std::cout << "FAIL.\n";
    }

    return 0;
}

