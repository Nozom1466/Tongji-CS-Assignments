#include <stdio.h>
union Float2Binary {
    float f;
    unsigned char bytes[sizeof(float)];
};

void printBinary(float num) {
    union Float2Binary converter;
    converter.f = num;
    
    printf("Binary code��");
    for (int i = sizeof(float) - 1; i >= 0; i--) {
        for (int j = 7; j >= 0; j--) {
            printf("%d", (converter.bytes[i] >> j) & 1);
        }
        printf(" ");
    }
    printf("\n");
}

int main() {
    float number;
    printf("Float number��");
    scanf("%f", &number);
    printBinary(number);
    return 0;
}
