/*
sp. c_1 <= c_2 <= c_3 ... <= c_n
for each c_k, i < k, j < k, c_i + c_j <= c_k.
the minimum of c_k would be the sum of c_{k - 1} + c_{k - 2}
(for infinite total length L, min c_k <=> max num of L's legal separation)
*/
#include <stdio.h>

int fibonacci(int n) {
    if (n <= 0) {
        return 0;
    } else if (n == 1 || n == 2) {
        return 1;
    } else {
        int a = 1, b = 1, c;
        for (int i = 3; i <= n; i++) {
            c = a + b;
            a = b;
            b = c;
        }
        return b;
    }
}

int getArraySum(int* array, int length) {
	int acc = 0;
	for (int i = 0;i < length; i++) {
		acc += array[i];
	}
	return acc;
} 

int printArray(int* arr, int length) {
	for (int i = 0;i < length; i++) {
		printf("%d ", arr[i]);
	}
	printf("\n");
}

int check(int* arr, int length) {
	for (int i = 0; i < length - 2; i++) {
		if (arr[i] + arr[i + 1] > arr[i + 2]) {
			return 0;
		}
	}
	return 1;
}


int rev(int start, int remainder, int depth, int* adder, int snt, int* array) {
	if (depth > 4) {
		if (check(adder, 5) && getArraySum(adder, 5) == snt) {
			for (int j = 0; j < 5; j++) {
				array[j + 2] += adder[j];
			}
			printArray(array, 7);
			for (int j = 0; j < 5; j++) {
				array[j + 2] -= adder[j];
			}
		}
		return;
	}
	
	for (int i = start; i <= remainder - start; i++) {
		adder[depth] = i;
		rev(start + i, remainder, depth + 1, adder, snt, array);
	}
}


int main() {
    int totalLength = 50;
    int maxN = 1; 
	int nums[totalLength];
	
	int pos = 0;
    while (fibonacci(maxN) <= totalLength) {
    	nums[pos++] = fibonacci(maxN);
    	maxN++;
    }
    
    int j;
    for (j = 0; j < pos; j++) {
    	if (getArraySum(nums, j) > totalLength) {
    		break;
		}
	}
	int remainder = totalLength - getArraySum(nums, j - 1);
	int adder[5];
	int array[7];
	for (int i = 0;i < 7; i++) {
		array[i] = nums[i];
	} 
	for (int i = 0; i < 5; i++) {
		adder[i] = 0;
	} 
	
	rev(0, remainder, 0, adder, remainder, array);
	printf("Number of segmentation: %d", j - 1);
	
	return 0;
}




