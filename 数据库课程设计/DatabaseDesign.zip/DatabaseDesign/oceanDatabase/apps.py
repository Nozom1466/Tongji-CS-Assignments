from django.apps import AppConfig


class OceandatabaseConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "oceanDatabase"
