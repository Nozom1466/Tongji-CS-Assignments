
var login_name = window.localStorage.getItem("user_name");


var formName = {name: login_name};
var isChanged = false;
console.log(formName)

$.ajax({
    type: "POST",
    url: base_url + "load", // 替换成你的Django端点URL
    contentType: 'application/json',
    headers: {
        'X-CSRFToken': csrfmiddlewaretoken
    },
    data: JSON.stringify(formName),
    success: function(data) {
        // 处理成功响应
        user_info = data.bolb[0]
        console.log(user_info)
        $("#first_name").attr("value",user_info.user_name);
        $("#email").attr("value", user_info.email);

        // 这里可以执行其他操作，如页面重定向或显示成功消息
    },
    error: function(xhr, textStatus, errorThrown) {
        // 处理错误响应
        console.error("发送数据时出错:", textStatus, errorThrown);
        // 这里可以显示错误消息给用户
    }
});


document.getElementById('submitBtn').addEventListener('click', function() {
    console.log(312121212121)
    var username = document.getElementById('first_name').value;
      var password = document.getElementById('last_name').value;
      var new_password = document.getElementById('new_pass').value


      // 准备要发送的数据
      var data = {
            user_name: username,
            password: password,
            new_password: new_password
      };

      // 发送 AJAX 请求
      $.ajax({
        url: base_url,
        type: 'POST',
        contentType: 'application/json',
          headers: {
                'X-CSRFToken': csrfmiddlewaretoken
            },
        data: JSON.stringify(data),
        success: function(response) {
          // 请求成功的处理逻辑
            console.log(response)
          if (response.status) {
              if (document.getElementById('last_name').classList.contains('is-invalid')) {
                  document.getElementById('last_name').classList.remove('is-invalid')
              }
              document.getElementById('last_name').classList.add('is-valid')
              document.getElementById('error-prompt').style.display = 'none';

             console.log(123456)
              isChanged = true;

          }
          else {
              document.getElementById('last_name').classList.add('is-invalid');
              document.getElementById('error-prompt').style.display = 'block';
              console.log('sb')
              isChanged = false;
          }
          document.getElementById('notifText').innerText = isChanged? "密码成功修改": "密码修改失败";

        },
        error: function(xhr, status, error) {
          // 请求失败的处理逻辑
          console.error('发生错误：', error);
        }


    });
})