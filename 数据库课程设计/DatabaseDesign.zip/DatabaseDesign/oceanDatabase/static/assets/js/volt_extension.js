var selectStateInputEl = document.querySelector("#area-type");
if (selectStateInputEl) {
  const choices = new Choices(selectStateInputEl);
}

var selectStateInputEl = document.querySelector("#analysis-type");
if (selectStateInputEl) {
  const choices = new Choices(selectStateInputEl);
}

for (var i = 0; i < 5; i++) {
  var selectStateInputEl = document.querySelector("#filter" + String(i + 1));
  if (selectStateInputEl) {
    const choices = new Choices(selectStateInputEl);
  }
}

for (var i = 0; i < 5; i++) {
  var selectStateInputEl = document.querySelector("#add-filter" + String(i + 1));
  if (selectStateInputEl) {
    const choices = new Choices(selectStateInputEl);
  }

  var selectStateInputEl = document.querySelector("#modify-filter" + String(i + 1));
  if (selectStateInputEl) {
    const choices = new Choices(selectStateInputEl);
  }
}

console.log(window.localStorage.getItem("isAdmin"))


function bindDeleteItems() {
    var submitBtns = document.querySelectorAll(".deleteItemBtn");

    for (var i = 0; i < submitBtns.length; i++) {
        submitBtn = submitBtns[i];

        submitBtn.addEventListener("click", function(event) {
            // 获取表单中的信息
            var submitBtnClass = event.target.classList;
            var lastClassValue = submitBtnClass[submitBtnClass.length - 1];
            var rightSubmitButton = document.getElementById(`modal-modify${lastClassValue}`).querySelector('.modify-data-submit-btn')
            console.log(rightSubmitButton)

            var formData = {
                'ID': rightSubmitButton.classList[submitBtn.classList.length - 1],
            };
            console.log(formData)


            $.ajax({
                type: "POST",
                url: base_url + "delete_item",
                data: JSON.stringify(formData),
                headers: {
                    'X-CSRFToken': csrfmiddlewaretoken
                },
                dataType: "json",
                success: function(data) {
                    // 处理成功响应
                    console.log("DDD:", data);
                    // 这里可以执行其他操作，如页面重定向或显示成功消息
                },
                error: function(xhr, textStatus, errorThrown) {
                    // 处理错误响应S
                    console.error("发送数据时出错:", textStatus, errorThrown);
                    // 这里可以显示错误消息给用户
                }
            });
        });
    }

    for (var i = 0; i < 5; i++) {
      var selectStateInputEl = document.querySelector("#modify-filter" + String(i + 1));
      if (selectStateInputEl) {
        const choices = new Choices(selectStateInputEl);
      }
    }


    var modifyBtns = document.querySelectorAll(".modify-data-submit-btn");
    console.log(modifyBtns)
    for (var i = 0; i < modifyBtns.length; i++) {
        modifyBtn = modifyBtns[i];
        modifyBtn.addEventListener("click", function(event) {
            console.log(event)
            // 获取提交按钮的最后一个class属性值
            var submitBtnClass = event.target.classList;
            var lastClassValue = submitBtnClass[submitBtnClass.length - 1];
            // 获取filter1和filter2的
            console.log(`modal-modify${lastClassValue}`)
            var filter1Value = document.getElementById(`modal-modify${lastClassValue}`).querySelector(`.w-100`).value;
            var filter2Value = document.getElementById(`modal-modify${lastClassValue}`).querySelector(`.modify-filter2 input`).value;
            console.log(submitBtnClass)


            // 创建JSON对象
            var dataToSend = {
              field: filter1Value,
              target: filter2Value,
              id: lastClassValue
            };
            console.log(dataToSend)

            // 使用$ajax方法发送JSON数据给后端
            $.ajax({
              url: base_url + "modify_item",
              type: 'POST',
                headers: {
                    'X-CSRFToken': csrfmiddlewaretoken
                },
              data: JSON.stringify(dataToSend),
              contentType: 'application/json',
              success: function(response) {
                // 处理后端返回的响应
                console.log('成功发送数据到后端:', response);
              },
              error: function(xhr, status, error) {
                // 处理发送失败的情况
                console.error('发送数据到后端失败:', error);
              }
            });

        });
    }




}



// filter item
document.addEventListener('DOMContentLoaded', function() {
  document.getElementById('search-btn-query').addEventListener('click', function() {
    // 获取所有filter的值
    var filter1Value = document.getElementById('filter1').value;
    var filter2Value = document.getElementById('filter2').value;

    // 获取滑动条的当前值
    var lowValue = parseFloat(document.getElementById('input-slider-range-value-low').innerText);
    var highValue = parseFloat(document.getElementById('input-slider-range-value-high').innerText);


    var start_date = $("#start-date").val();
    var end_date = $("#end-date").val()
      console.log(`start: ${start_date}`)

      if (start_date === '') {
          start_date = '14/01/2003'
      }

      if (end_date === '') {
          end_date = '14/01/2010'
      }


    // 创建包含所有filter值的对象
    var data = {
      filter1:  filter1Value,
      filter2: filter2Value,
      start_date: start_date,
      end_date: end_date,
      depth_min: lowValue,
      depth_max: highValue
    };

    $.ajax({
        url: base_url,
        type: 'POST',
        contentType: 'application/json',
        headers: {
            'X-CSRFToken': csrfmiddlewaretoken
        },
        data: JSON.stringify(data),
        success: function(response) {
            // 请求成功的处理逻辑
            console.log(response);

            /*
            * MARIS_ID, sample_type,
            * */

            var lastSlashIndex  = base_url.lastIndexOf("/", base_url.lastIndexOf("/") - 1);
            var invoice_url = base_url.substr(0, lastSlashIndex + 1) + "invoice";
            var delete_url = base_url;

            var myData = {
                "headings": [
                    "样本类型",
                    "深度 (m)",
                    "纬度",
                    "经度",
                    "采样时间",
                    "平均 MDA",
                    "操作"
                ],
                "data": response.bolb.map(function(item, idx) {
                    invoice_url_info = invoice_url + "?bolb=" + encodeURIComponent(JSON.stringify(item));
                    delete_url_info = delete_url + "?bolb=" + encodeURIComponent(JSON.stringify(item));
                    return [
                        item.sample_type ? item.sample_type : 'NULL',
                        item.nuclide ? item.nuclide : 'NULL',
                        item.sampling_depth.toString() || 'NULL',
                        item.latitude || 'NULL',
                        item.longitude || 'NULL',
                        item.sampling_start_datetime || 'NULL',
                        `<div style="display: flex; gap: 5px;">
                            <!-- 报告 -->
                            <a href=${invoice_url_info} class="text-secondary me-3">报告</a>
                            
                            <!-- 修改 -->
                            <a class="text-success me-3" data-bs-toggle="modal" data-bs-target="#modal-modify${idx}" id="modal-modify-link">修改</a>
                            <div class="modal fade" id="modal-modify${idx}" tabindex="-1" role="dialog" aria-labelledby="modal-modify" aria-hidden="true">
                                <div class="marian-sel modal-dialog modal-dialog-centered" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                          <h2 class="h6 modal-title">修改数据</h2>
                                          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                              <div class="accordion" id="area1p">
                                                  <div class="modify-filter1 mb-3" style="grid-column-start: 1;rid-row-start: 1;">
                                                        <label class="my-1 me-2" for="modify-filter1">Field</label>
                                                        <select id="modify-filter1" class="w-100" name="modify-filter1">
                                                            <option value="sampling_depth">depth</option>
                                                            <option value="Cs-137">type</option>
                                                            <option value="Pb-210">time</option>
                                                        </select>
                                                  </div>
            
                                                  <div class="modify-filter2" style="grid-column-start: 2;rid-row-start: 1;">
                                                        <label for="usernameValidate">Modified value</label>
                                                        <input type="text" class="form-control">
                                                  </div>
                                              </div>
                                            </div>
                                            <div class="modal-footer">
                                              <button type="button" class="btn btn-secondary modify-data-submit-btn ${idx}" data-bs-dismiss="modal">
                                                提交
                                              </button>
                                              <button type="button" class="btn btn-link text-gray ms-auto" data-bs-dismiss="modal">
                                                Close
                                              </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- 删除 -->
                            <a class="text-danger me-3 deleteItemBtn ${idx}" data-bs-toggle="modal" data-bs-target="#deleteNotification">删除</a>
                            <div class="modal fade" id="deleteNotification" tabindex="-1" role="dialog" aria-labelledby="modalTitleNotify" aria-hidden="true">
                              <div class="modal-dialog modal-dialog-centered" role="document">
                                <div class="modal-content">
                                  <div class="modal-header">
                                    <p class="modal-title" id="modalTitleNotify">
                                      提示信息
                                    </p>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                  </div>
                                  <div class="modal-body">
                                    <div class="py-3 text-center">
                                      <h2 class="h4 modal-title my-3 text-danger">
                                        数据已删除！
                                      </h2>
                                      <p>请刷新重新检索。</p>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                         </div>`
                    ];
                })
            };



            console.log(myData)
            dttt.data = [];

            // 获取表格元素
            if (myData.data.length > 0) {
                dttt.insert(myData);
            }

            bindDeleteItems();


        },
        error: function(xhr, status, error) {
            // 请求失败的处理逻辑
            console.error('请求失败:', error);
        }
    });
  });
});


// add item
document.addEventListener("DOMContentLoaded", function() {
    var submitBtn = document.getElementById("add-data-submit-btn");
    submitBtn.addEventListener("click", function() {
        // 获取表单中的信息

        var formData = {
            'nuclide': $("#add-filter1").val(),
            'sampleType': $("#add-filter2").val(),
            'samplingDepth': $(".add-filter3 input").val(),
            'altitude': $(".add-filter4 input").val(),
            'longitude': $(".add-filter5 input").val(),
            'temperature': $(".add-filter6 input").val(),
            'samplingDate': $("#sampling-date").val(),
            'activityOrMDA': $(".add-filter8 input").val(),
            'additionalInfo': $("#textarea").val()
        };

        console.log(formData)


        $.ajax({
            url: base_url + "add_item", // 替换成你的Django端点URL
            type: "POST",
            contentType: 'application/json',
            headers: {
                'X-CSRFToken': csrfmiddlewaretoken
            },
            data: JSON.stringify(formData),
            success: function(data) {
                // 处理成功响应
                console.log("数据成功发送到后端:", data);
                // 这里可以执行其他操作，如页面重定向或显示成功消息
                console.log(localStorage.getItem("isAdmin"))

                if (localStorage.getItem("isAdmin") === "0") {
                    return;
                }

                const now = new Date();
                const year = now.getFullYear();
                const month = String(now.getMonth() + 1).padStart(2, '0');
                const day = String(now.getDate()).padStart(2, '0');

                const formattedDateTime = `${year}-${month}-${day}`;

                var new_waiting = {
                    "title": `添加样本`,
                    "content": `添加${$("#add-filter2").val()}样本，核素${$("#add-filter1").val()}，经度${$(".add-filter5 input").val()}，纬度${$(".add-filter4 input").val()}，深度${$(".add-filter3 input").val()}`,
                    "time": formattedDateTime
                }

                $.ajax({
                    url: base_url + "add_waiting", // 替换成你的Django端点URL
                    type: "POST",
                    contentType: 'application/json',
                    headers: {
                        'X-CSRFToken': csrfmiddlewaretoken
                    },
                    data: JSON.stringify(new_waiting),
                    success: function(data) {
                        // 处理成功响应
                        console.log("数据成功发送到后端:", data);
                        // 这里可以执行其他操作，如页面重定向或显示成功消息
                    },
                    error: function(xhr, textStatus, errorThrown) {
                        // 处理错误响应
                        console.error("发送数据时出错:", textStatus, errorThrown);
                        // 这里可以显示错误消息给用户
                    }
                });
            },
            error: function(xhr, textStatus, errorThrown) {
                // 处理错误响应
                console.error("发送数据时出错:", textStatus, errorThrown);
                // 这里可以显示错误消息给用户
            }
        });




    });
});


//modify item



// map
if (base_url.search('map') != -1) {

}


document.addEventListener('DOMContentLoaded', function() {
      // 获取 localStorage 中的 isAdmin 值
      var isAdmin = localStorage.getItem('isAdmin');

      // 检查 isAdmin 是否等于 0

      if (isAdmin === '0') {
        // 显示 admin-item
        document.getElementById('data-review').style.display = 'block';
        document.getElementById('user-manage').style.display = 'block';
      } else {
        document.getElementById('data-review').style.display = 'none';
        document.getElementById('user-manage').style.display = 'none';
      }

      if (isAdmin === '1' || isAdmin === '0') {
          document.getElementById('data-lookup').style.display = 'block';
          document.getElementById('data-source').style.display = 'block';
      } else {
          document.getElementById('data-lookup').style.display = 'none';
          document.getElementById('data-source').style.display = 'none';
      }
    });




