var mapdata = {
        test: 10086
    };

    $.ajax({
            url: base_url,
            type: 'POST',
            contentType: 'application/json',
            headers: {
                'X-CSRFToken': csrfmiddlewaretoken
            },
            data: JSON.stringify(mapdata),
            success: function (response) {
                // 请求成功的处理逻辑
                console.log("MAP SUCCESS" + response);

                console.log(response.bolb)

                // var tempListings = [
                //     {
                //         url: "#",
                //         latLng: [37.7, -123.41],
                //         name: "Call with Jane",
                //         date: "Tomorrow at 12:30 PM",
                //     },
                //
                // ];
                var tempListings = response.bolb.map(function(item) {
                    return {
                        url: "#",
                        latLng: [parseFloat(item.latitude), parseFloat(item.longitude)],
                        name: item.nuclide, // 这里将实验室名称作为元素名称
                        date: item.sampling_start_datetime, // 日期暂时设为 "N/A"
                        mda: item.activity_or_mda
                    };
                });

                // 清空之前的地图标记
                map_maplisting.eachLayer(function (layer) {
                    map_maplisting.removeLayer(layer);
                });

                console.log(tempListings);

                // 使用后端返回的数据更新地图标记
                tempListings.forEach(function (listing) {
                    var popupHtml = `
                    <a href="${listing.url}" class="card card-article-wide border-0 flex-column no-gutters no-hover">
                        <div class="card-body py-0 d-flex flex-column justify-content-between col-12">
                            <h4 class="h5 fw-normal mb-2">${listing.name}</h4>
                            <div class="d-flex"><div class="icon icon-xs icon-tertiary me-2"><span class="fas fa-clock"></span></div><div class="font-xs text-dark">${listing.date}</div></div>
                        </div>
                    </a>
                `;

                    var greenIcon = L.icon({iconUrl:static_folder + 'assets/img/marker-g.png'}),
                        redIcon = L.icon({iconUrl:static_folder + 'assets/img/marker-r.png'}),
                        yellowIcon = L.icon({iconUrl:static_folder + 'assets/img/marker-y.png'});

                    function getColorByMDA(mda) {
                        if (mda < 2.5) {
                            return greenIcon; // MDA 小于 10，设置为绿色
                        } else if (mda < 5) {
                            return yellowIcon; // MDA 在 10 到 20 之间，设置为黄色
                        } else {
                            return redIcon; // MDA 大于等于 20，设置为红色
                        }
                    }



                    // var marker = L.marker(listing.latLng, {icon: map_icon}).addTo(map_maplisting);
                    var marker = L.marker(listing.latLng, {
                        icon: getColorByMDA(listing.mda)}).addTo(map_maplisting);

                    marker.bindPopup(popupHtml);
                });

                console.log("over")
            },
            error: function (xhr, status, error) {
                // 请求失败的处理逻辑
                console.error('请求失败:', error);
            }
        });