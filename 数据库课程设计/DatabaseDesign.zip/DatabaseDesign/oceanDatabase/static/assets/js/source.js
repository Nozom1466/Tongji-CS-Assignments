var user_table = document.getElementById("source-datatable");
  if (user_table) {
    var user_dataTable = new simpleDatatables.DataTable(user_table);
  }


document.getElementById('searchContent').addEventListener("click", function(event) {
    var formData = {
            'source_name': $("#email").val(),
        };
    console.log(formData)

    $.ajax({
        url: base_url + 'search_source',
        type: 'POST',
        data: formData,
        headers: {
            'X-CSRFToken': csrfmiddlewaretoken
        },

        // data: JSON.stringify(data),
        success: function(response) {
            // 请求成功的处理逻辑
            console.log(response.bolb);

            /*
            * MARIS_ID, sample_type,
            * */

            var lastSlashIndex  = base_url.lastIndexOf("/", base_url.lastIndexOf("/") - 1);
            var invoice_url = base_url.substr(0, lastSlashIndex + 1) + "invoice";
            var delete_url = base_url;

            var myData = {
                "headings": [
                    "放射源名称",
                    "经度",
                    "纬度",
                    "状态",
                    "主要元素",
                    "操作",
                ],
                "data": response.bolb.map(function(item, idx) {
                    console.log(idx)
                    return [
                        item.source_name ? item.source_name : 'NULL',
                        item.lg ? "" + item.lg : 'NULL',
                        item.at ? "" + item.at : 'NULL',
                        item.status ? item.status : 'NULL',
                        item.nuclide ? item.nuclide : 'NULL',
                        `<div style="display: flex; gap: 10px;">
                            <!-- 修改 -->
                            <a class="text-success me-3" data-bs-toggle="modal" data-bs-target="#modal-modify${idx}" id="modal-modify-link">修改</a>
                            <div class="modal fade" id="modal-modify${idx}" tabindex="-1" role="dialog" aria-labelledby="modal-modify" aria-hidden="true">
                                <div class="marian-sel modal-dialog modal-dialog-centered" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                          <h2 class="h6 modal-title">修改数据</h2>
                                          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                              <div class="accordion" id="area1p">
                                                  <div class="modify-filter1 mb-3" style="grid-column-start: 1;rid-row-start: 1;">
                                                        <label class="my-1 me-2" for="modify-filter1">Field</label>
                                                        <select id="modify-filter${idx}" class="w-100" name="modify-filter1">
                                                            <option value="user_name">放射源名称</option>
                                                            <option value="email">经度</option>
                                                            <option value="role">纬度</option>
                                                        </select>
                                                  </div>
            
                                                  <div class="modify-filter2" style="grid-column-start: 2;rid-row-start: 1;">
                                                        <label for="usernameValidate">Modified value</label>
                                                        <input type="text" class="form-control">
                                                  </div>
                                              </div>
                                            </div>
                                            <div class="modal-footer">
                                              <button type="button" class="btn btn-secondary modify-data-submit-btn ${idx}" data-bs-dismiss="modal">
                                                提交
                                              </button>
                                              <button type="button" class="btn btn-link text-gray ms-auto" data-bs-dismiss="modal">
                                                Close
                                              </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            
                            
                            <!-- 删除 -->
                            <a class="text-danger me-3 deleteItemBtn ${idx}" data-bs-toggle="modal" data-bs-target="#deleteNotification">删除</a>
                            <div class="modal fade" id="deleteNotification" tabindex="-1" role="dialog" aria-labelledby="modalTitleNotify" aria-hidden="true">
                              <div class="modal-dialog modal-dialog-centered" role="document">
                                <div class="modal-content">
                                  <div class="modal-header">
                                    <p class="modal-title" id="modalTitleNotify">
                                      提示信息
                                    </p>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                  </div>
                                  <div class="modal-body">
                                    <div class="py-3 text-center">
                                      <h2 class="h4 modal-title my-3 text-danger">
                                        数据已删除！
                                      </h2>
                                      <p>请刷新重新检索。</p>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                         </div>`
                    ]
                })
            };

            console.log(myData)
            user_dataTable.data = [];

            // 获取表格元素
            if (myData.data.length > 0) {
                user_dataTable.insert(myData);
            }





            var modifyBtns = document.querySelectorAll(".modify-data-submit-btn");

            for (var i = 0; i < modifyBtns.length; i++) {
                var selectStateInputEl = document.querySelector("#modify-filter" + i);

                  if (selectStateInputEl) {
                    const choices = new Choices(selectStateInputEl);
                  }
                console.log(selectStateInputEl)
            }




            console.log(modifyBtns)
            for (var i = 0; i < modifyBtns.length; i++) {
                modifyBtn = modifyBtns[i];
                console.log(modifyBtn)
                modifyBtn.addEventListener("click", function(event) {
                    // 获取提交按钮的最后一个class属性值
                    var submitBtnClass = event.target.classList;
                    var lastClassValue = submitBtnClass[submitBtnClass.length - 1];
                    // 获取filter1和filter2的
                    console.log(`modal-modify${lastClassValue}`)
                    var filter1Value = document.getElementById(`modal-modify${lastClassValue}`).querySelector(`.w-100`).value;
                    var filter2Value = document.getElementById(`modal-modify${lastClassValue}`).querySelector(`.modify-filter2 input`).value;
                    console.log(submitBtnClass)

                    // 创建JSON对象
                    var dataToSend = {
                      field: filter1Value,
                      target: filter2Value,
                      id: lastClassValue
                    };
                    console.log(dataToSend)

                    // 使用$ajax方法发送JSON数据给后端
                    $.ajax({
                      url: base_url + "modify_item_user",
                      type: 'POST',
                        headers: {
                            'X-CSRFToken': csrfmiddlewaretoken
                        },
                      data: JSON.stringify(dataToSend),
                      contentType: 'application/json',
                      success: function(response) {
                        // 处理后端返回的响应
                        console.log('成功发送数据到后端:', response);
                      },
                      error: function(xhr, status, error) {
                        // 处理发送失败的情况
                        console.error('发送数据到后端失败:', error);
                      }
                    });

                });
            }

            var submitBtns = document.querySelectorAll(".deleteItemBtn");
            for (var i = 0; i < submitBtns.length; i++) {
                submitBtn = submitBtns[i];

                submitBtn.addEventListener("click", function(event) {
                    // 获取表单中的信息
                    var submitBtnClass = event.target.classList;
                    var lastClassValue = submitBtnClass[submitBtnClass.length - 1];
                    var rightSubmitButton = document.getElementById(`modal-modify${lastClassValue}`).querySelector('.modify-data-submit-btn')
                    console.log(rightSubmitButton)

                    var formData = {
                        'ID': rightSubmitButton.classList[submitBtn.classList.length - 1],
                    };
                    console.log(formData)


                    $.ajax({
                        type: "POST",
                        url: base_url + "delete_item_user",
                        data: JSON.stringify(formData),
                        headers: {
                            'X-CSRFToken': csrfmiddlewaretoken
                        },
                        dataType: "json",
                        success: function(data) {
                            // 处理成功响应
                            console.log("DDD:", data);
                            // 这里可以执行其他操作，如页面重定向或显示成功消息
                        },
                        error: function(xhr, textStatus, errorThrown) {
                            // 处理错误响应S
                            console.error("发送数据时出错:", textStatus, errorThrown);
                            // 这里可以显示错误消息给用户
                        }
                    });
                });
            }



            // bindDeleteItems();
        },
        error: function(xhr, status, error) {
            // 请求失败的处理逻辑
            console.error('请求失败:', error);
        }
    });

})

document.getElementById('addSource').addEventListener("click", function() {
        // 获取表单中的信息
    console.log($("#states").val())

        var formData = {
            'source_name': $("#email").val(),
            'lg': $("#firstName").val(),
            'at': $("#usernameValidate").val(),
            'nuclide': $("#states").val().join(','),
            'time': $("#birthday").val(),
            'comment': $("#textarea").val(),
            'country': $("#country").val(),
        };
        console.log(formData)


        $.ajax({
            type: "POST",
            url: base_url + "add_source", // 替换成你的Django端点URL
            data: formData,
            headers: {
                'X-CSRFToken': csrfmiddlewaretoken
            },
            dataType: "json",
            success: function(data) {
                // 处理成功响应
                console.log("数据成功发送到后端:", data);
                // 这里可以执行其他操作，如页面重定向或显示成功消息
                console.log(typeof localStorage.getItem("isAdmin"))

                if (localStorage.getItem("isAdmin") === "0") {
                    return;
                }

                console.log("kkkkkkkkkkkkkkkkkkkkkkk")

                const now = new Date();
                const year = now.getFullYear();
                const month = String(now.getMonth() + 1).padStart(2, '0');
                const day = String(now.getDate()).padStart(2, '0');

                const formattedDateTime = `${year}-${month}-${day}`;

                var new_waiting = {
                    "title": `添加放射源`,
                    "content": `添加${$("#email").val()}放射源，核素${$("#states").val().join(',')}，经度${$("#firstName").val()}，纬度${$("#usernameValidate").val()}，ISO: ${$("#country").val()}`,
                    "time": formattedDateTime
                }

                $.ajax({
                    url: base_url + "add_waiting", // 替换成你的Django端点URL
                    type: "POST",
                    contentType: 'application/json',
                    headers: {
                        'X-CSRFToken': csrfmiddlewaretoken
                    },
                    data: JSON.stringify(new_waiting),
                    success: function(data) {
                        // 处理成功响应
                        console.log("数据成功发送到后端:", data);
                        // 这里可以执行其他操作，如页面重定向或显示成功消息
                    },
                    error: function(xhr, textStatus, errorThrown) {
                        // 处理错误响应
                        console.error("发送数据时出错:", textStatus, errorThrown);
                        // 这里可以显示错误消息给用户
                    }
                });
            },
            error: function(xhr, textStatus, errorThrown) {
                // 处理错误响应
                console.error("发送数据时出错:", textStatus, errorThrown);
                // 这里可以显示错误消息给用户
            }
        });


    });