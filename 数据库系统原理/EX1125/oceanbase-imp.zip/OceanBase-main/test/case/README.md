# miniob-test
miniob自动化功能测试

运行所有测试用例：
```bash
python3 miniob_test.py
```

运行 basic 测试用例
```bash
python3 miniob_test.py --test-cases=basic
```

> 如果要运行多个测试用例，则在 --test-cases 参数中使用 ',' 分隔写多个即可

更多运行方法和参数可以参考 miniob_test.py

