## Extra Credit: 手写实现回归算法模型

手写实现部分分别实现了线性回归模型和多项式回归模型，包括 `initializer`, `optimizer`，`mse` 损失函数和正向反向传播过程。



### Initializer

初始化神经网络参数可以帮助模型收敛速度加快、同时防止模型参数的对称性带来的表达限制。本实验中实现了六种 `initializer` 初始化函数。

- `normal` : $\text{val} \sim \mathcal{N}(0, 1)$
- `uniform` : $\text{val} \sim \mathcal{U}(-1 / \text{num\_features}, 1 / \text{num\_features})$
- `zeros`： $\text{val} = 0$
- `ones`： $\text{val} = 1$
- `xavier_normal`: $\text{val} \sim \mathcal{N}(0, \sqrt{2 / (\text{num\_features} + \text{num\_neurons})})$
- `xavier_uniform`: $\text{val} \sim \mathcal{U}(-\sqrt{6 / (\text{num\_features} + \text{num\_neurons})}, \sqrt{6 / (\text{num\_features} + \text{num\_neurons})})$

其中 $\text{val}$ 为回归层中的权重值。





### Optimizer

`optimizer` 帮助网络实现反向传播，执行梯度下降操作。不同 `optimizer` 的选择对模型训练的收敛速度和结果有显著影响。某些选择 (如 `Adam` ) 可以帮助防止模型过拟合等。本实验中实现了 `SGD`, `momentum`, `RMSprop`和 ` Adam` optimizer。后三者为防止初始化为 0 对模型更新的影响，引入标准化过程保证梯度更新的平滑过渡。

此处公式以权重 `W` 的更新为例：

- `SGD`: $\text{w} := \text{w} - \eta \cdot \text{dw}$

- `momentum`: $\text{m}_t := \beta \cdot \text{m}_{t - 1} + (1 - \beta) \cdot \text{dw}, \quad \text{m}_t := \text{m}_t / (1 - \beta^{t}), \quad \text{w} := \text{w} - \eta \cdot \text{m}_t$

- `RMSprop`:  $\text{s}_t := \beta \cdot \text{s}_{t - 1} + (1 - \beta) \cdot (\text{dw})^2, \quad \text{s}_t := \text{s}_t / (1 - \beta^{t}), \quad \text{w} := \text{w} - \eta / \sqrt{\text{s}_t + \varepsilon}$

- `Adam` :  

  $$\text{m}_t := \beta \cdot \text{m}_{t - 1} + (1 - \beta) \cdot \text{dw}, \quad \text{m}_t := \text{m}_t / (1 - \beta^{t}); \\ \text{s}_t := \beta \cdot \text{s}_{t - 1} + (1 - \beta) \cdot (\text{dw})^2, \quad \text{s}_t := \text{s}_t / (1 - \beta^{t}); \\ \text{w} := \text{w} - \eta \cdot \text{m}_t / (\sqrt{\text{s}_t} + \varepsilon)$$

其中 $\varepsilon$ 保证分母不为0 ，通常设置为 `1e-6`



为保证训练过程调用一致性，在回归模型的参数更新过程中加入 `optional_args` 可选参数，在训练过程中实时更新。

```python
def get_optional_args(optimizer_type: str='SGD') -> Dict:
    """fill in optional arguments for different optimizers"""
    ...
    if optimizer_type == 'momentum':
            optional_args['prev_mm_w'] = 0
            optional_args['prev_mm_b'] = 0
        
class Model():
    ...
    def step(self):
        param_updated = self.optimizer(self.dw, self.db, self.lr, self.weight, 
                                       self.bias, **self.optional_args)
```



### Loss function

损失函数采用均方误差 `MSE` ：
$$
\text{MSE} = \frac{1}{n}\sum_{i = 1}^{n}(y_i - \hat y_i)^2
$$




### 可扩展性

调用 `optimizer` 和 `loss_fn`均采用返回函数的方式，尽可能保证开闭原则

```python
# loss functions
def mean_squared_error(y_pred: np.ndarray, y_std: np.ndarray, n: int):
    """Mean Squared Error, a.k.a MSE"""
    return np.sum((y_pred - y_std)**2) / n

def loss_fn(cate: str='mse'):
    """loss functions"""
    if cate=='mse':
        return mean_squared_error
    else:
        return NotImplemented
```

调用：

```python
self.optimizer = optimizer(optimizer_type)
```

新损失函数添加可模仿 `MSE` 函数，在 `loss_fn` 中返回对应函数实例即可





### 模型结构

回归模型内方法：

- `__init__()` ： 模型初始化、模型参数初始化
- `forward()`： 正向传播
- `loss_reg()`：计算 `loss`
- `backward()`: 反向传播
- `step()` ： `optimizer` 参数更新
- `print_params()`：日志输出
- `__name__()`：回归模型名称

回归模型内部分字段：

- `in_array`： 输入的批量数据
- `lr`：学习率
- `optimizer`： 优化器函数
- `optional_args`：与优化器对应的参数
- `initial`：参数初始化函数
- `w, b, dw, db`：模型参数
- `cache`：前向传播暂存值



```python
class RegressionModel():
    """Regression Model Structure"""
    def __init__(self, in_array, initializer_type, loss_fn_type, lr, optimizer_type):
        """initialize:
           in_array, batch_size, in_features, out_features, lr, optimizer_fn, 
           optional_args, initial_fn, weight, bias, loss_fn, loss, y_pred, cache"""
        pass
    
    def forward(self):
        """forward propagation"""
        pass
    
    def loss_reg(self, y_std):
        """calculate loss value"""
        pass
    
    def backward(self):
        """calculate partial derivatives for each trainable parameter"""
        pass
    
    def step(self):
        """update parameters using optimizer"""
        pass
    
    def print_params(self):
        """print log info"""
        pass
    
    def __name__(self):
        """class name"""
        pass
```





### Model 1: 线性回归

#### 数学模型

正向传播（批量）：
$$
Y = X \cdot W^T + b
$$
反向传播（梯度更新）：
$$
\text{dw}_j = \frac{1}{n}\sum_{i = 1}^{n}(y_i - \hat y_i) \cdot x_j
$$


#### 模型关键步骤实现

线性操作：

```python
# linear transformation
def linear(in_array: np.ndarray, weight: np.ndarray, bias: np.ndarray) -> np.ndarray:
    r"""
    linear transformation: y = xW^T + b

    Args:
        in_array: input array
        weight: input weight
        bias: input bias

    Shapes:
        - Input: (N, in_features)
        - Weight: (out_features, in_features)
        - Bias: (out_features)
        - Output: (N, out_features)
    """

    assert weight.shape[-1] == in_array.shape[-1], "ERR : input and weight dimensions not matched."

    return np.matmul(in_array, weight.T) + bias
```



反向传播：

```python
def backward(self, y_std):
        diff = self.y_pred - y_std
        self.dw = (1. / self.batch_size) * np.sum(self.in_array * diff, axis=0)
        self.db = (1. / self.batch_size) * np.sum(diff)
```







###  Model 2: 多项式回归

#### 数学模型

正向传播（批量）：
$$
y = \sum_{i=0}^{n} a_ix^i
$$
反向传播：
$$
\text{dw}_j = \frac{2}{n} \sum_{i = 1}^{n}(y_i - \hat y_i) \cdot x_j^{i}
$$


#### 模型关键步骤实现

多项式操作

```python
# polynomial transformation
def poly(in_array: np.ndarray, weight: np.ndarray, poly_deg: int=3) -> Tuple:
    """
    poly transformation: y = \sum_{i=0}^{n} a_ix^i

    Args:
        in_array: input array
        weight: coefficients in transformation
        poly_deg: the degree of polynomial

    Shapes:
        - Input: (N, in_features)
        - Weight: (depth, )
    """
    poly = PolynomialFeatures(poly_deg)
    base_items = poly.fit_transform(in_array)
    assert base_items.shape[-1] == weight.shape[-1], "shape of weight mismatches with polynomial shape."
    res = np.sum(base_items * weight, axis=1, keepdims=True)

    return res, base_items

def get_poly_dim(num_features: int, poly_deg: int) -> int:
    """test on simple polynomial to check the number of items """
    arr_test = np.zeros([1, num_features])
    poly = PolynomialFeatures(poly_deg)
    return poly.fit_transform(arr_test).shape[-1]
```

此处使用 `sklearn.preprocessing` 中 `PolynomialFeatures` 产生多项式各项



反向传播：

```python
 def backward(self, y_std):
        diff = self.y_pred - y_std
        self.dw = (2. / self.batch_size) * np.sum(diff * self.cache_poly_matrix, axis=0)
```





### 数据集测试

#### 训练

训练过程与 `log` 记录

```python
def training(model, labels, epochs: int=100, isLinear: int=False) -> Dict:
    """Training loop

    Args:
        model: regression model
        labels: target labels
        epochs: training epochs
        isLinear: Linear Regression or not (bias in result)
    """
    result = {}

    for epoch in range(epochs):
        model.forward()
        model.backward(labels)
        model.loss_reg(labels)
        model.step()
        print(f"Epoch: {epoch}", end=" ")
        model.print_params()

    result['name'] = model.__class__.__name__
    result['weight'] = model.weight
    if isLinear:
        result['bias'] = model.bias
    result['loss'] = model.loss
    return result
```





#### 线性模型

线性数据生成（`feature`为1维）：

```python
def synthetic_linear_data(w,b,num_examples):
    X = np.random.normal(0,1,(num_examples,len(w[0])))
    y = np.matmul(X,w.T) + b
    y += np.random.normal(0,0.3,y.shape)
    return X, y.reshape((-1,1))

true_w = np.array([[1.2]])
true_b = [[4.2]]
features, labels = synthetic_linear_data(true_w,true_b,1000)
```



线性模型参数拟合结果：

```python
{'name': 'LinearRegression',
 'weight': array([[1.18326039]]),
 'bias': array([4.19939606]),
 'loss': 0.09418713802447212}
```

线性模型拟合可视化：

![linear_model_synthetic_dataset](D:\MachineLearning2023\PA1\linear_model_synthetic_dataset.jpg)



#### 多项式模型

多项式模型数据生成（`sin`函数拟合）

```python
def synthetic_poly_data():
    x = np.linspace(0, 1, 100)
    y = np.sin(5 * x) + 0.1 + np.random.randn(len(x)) * 0.1
    return x, y

syn_poly_data = synthetic_poly_data()
poly_features = syn_poly_data[0][:, np.newaxis]
poly_labels = syn_poly_data[1][:, np.newaxis]
```



多项式模型参数拟合结果（10次多项式）：

```python
{'name': 'PolyRegression',
 'weight': array([[ 0.36378184,  3.16405537, -3.13549206, -3.06904324, -0.87799048,
         -1.38264578,  0.31971563,  1.35934368,  1.88588701, -0.05626168,
          0.88270087]]),
 'loss': 0.02327417657968127}
```



多项式模型拟合可视化：

![polynomial_model_synthetic_dataset](D:\MachineLearning2023\PA1\polynomial_model_synthetic_dataset.jpg)









